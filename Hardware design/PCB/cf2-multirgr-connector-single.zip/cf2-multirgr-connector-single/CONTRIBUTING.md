Contributing
============

👍🎉 Thanks a lot for considering contributing 🎉👍

We welcome and encourage contribution. There is many way to contribute: you can
write bug report, contribute code or documentation.
You can also go to the [bitcraze forum](https://forum.bitcraze.io) and help others.

## Reporting issues

If you find any issues with the projekt please submit an issue. The more information the better.

## Improvements request and proposal

If you would like to propose new changes please submit an issue.

## Contributing mechanical models / Pull requests

We welcome contributions for the template but please describe/document the changes and create an issue for them.
