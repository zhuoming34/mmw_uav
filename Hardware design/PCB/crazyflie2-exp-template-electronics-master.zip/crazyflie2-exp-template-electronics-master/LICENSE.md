The content, code and samples in this project are licensed under the 
[Creative Commons Attribution 3.0 License](http://creativecommons.org/licenses/by/3.0/)

